Drop client subfolders here (e.g. input\AcmeMedical\billing_combined\). 
See Getting_Started.md for folder structure. 
